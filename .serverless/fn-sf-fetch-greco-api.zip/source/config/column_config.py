########################################################################################################################
#
# column_config.py
#   - Contains a dictionary that maintains a list of columns for each greco table for which, exact-match,
#     date-range & timestamp search should be implemented
#
# Author(s): Yash Parakh
#
# Changelog:
#   2023-02-23 - ypar3236 - Created
#
########################################################################################################################

# Dictionary Structure:
# column_dict = {
#     "table_name": {
#        "col": [List of all columns except seq_no]
#        "exact_match": [list of columns],
#        "timestamp": [list of columns],
#        "date_range": [list of columns]
#     }
# }

column_dict = {
    "greco_birthday_listing_report": {
        "col": ['id', 'employee', 'birthday', 'address_1', 'address_2', 'city', 'state', 'zip_code'],
        "exact_match": [
            'seq_no',
            'id',
            'birthday',
            'zip_code',
            'state'
        ],
        "timestamp": [],
        "date_range": []
    },
    "greco_401k_census": {
        "col": ['co', 'id', 'last_name', 'first_name', 'm', 'ssn', 'sex', 'birthdate', 'hiredate', 'rehiredate',
                'termdate', 'marital_status', 'address_1', 'address_2', 'city', 'state', 'zip', 'emp_status',
                'union_code', 'er_pre', 'er_post', 'ee_pre', 'ee_post', 'loan_1', 'loan_2', 'loan_3', 'loan_4',
                'loan_5', 'loan_6', 'loan_7', 'loan_8', 'loan_9', 'hours', 'gross', 'ytd_er_pre', 'ytd_er_post',
                'ytd_ee_pre', 'ytd_ee_post', 'ytd_loan_1', 'ytd_loan_2', 'ytd_load_3', 'ytd_loan_4', 'ytd_loan_5',
                'ytd_loan_6', 'ytd_loan_7', 'ytd_loan_8', 'ytd_loan_9', 'ytd_hours', 'ytd_gross'],
        "exact_match": [
            'id',
            'co'
        ],
        "timestamp": [
            'birthdate',
            'hiredate',
            'rehiredate',
            'termdate'
        ],
    },
    "greco_accural_balance": {
        "col": ['id', 'employee', 'rate', 'length_of_service', 'code', 'accrual_rate', 'start_date', 'hours_used',
                'hours_available', 'days_used', 'days_available'],
        "exact_match": [
            'seq_no',
            'id',
            'code',
        ],
        "timestamp": [
            'length_of_service',
            'start_data'
        ],
        "date_range": []
    },
    "greco_anniversary_report": {
        "col": ['id', 'employee', 'hire_date', 'rehire_date', 'adj_seniority', 'seniority', 'pay_rate', 'address_1',
                'address_2', 'city', 'zip'],
        "exact_match": [
            'seq_no',
            'id',
            'zip',
        ],
        "timestamp": [
            'hire_date',
            'rehire_date',
            'adj_seniority'
        ],
        "date_range": []
    },
    "greco_benefits_reconciliation_report": {
        "col": ['employee', 'id', 'status', 'title'],
        "exact_match": [
            'seq_no',
            'id',
            'status',
        ],
        "timestamp": [
        ],
        "date_range": []
    },
    "greco_check_register_report": {
        "col": ['employee_id', 'employee_name', 'net_amount'],
        "exact_match": [
            'seq_no',
            'employee_id',
        ],
        "timestamp": [
        ],
        "date_range": []
    },
    "greco_employee_listing_report": {
        "col": ['employee', 'id', 'ssn', 'emp_status', 'emp_type', 'sui', 'pay_freq', 'rate_salary', 'rate_per'],
        "exact_match": [
            'seq_no',
            'id',
            'emp_status',
            'emp_type',
            'sui',
            'pay_freq'

        ],
        "timestamp": [
        ],
        "date_range": []
    },
    "greco_new_hire_report": {
        "col": ['id', 'employee', 'ssn', 'hire_date', 'change_reason', 'term_date', 'emp_status'],
        "exact_match": [
            'seq_no',
            'id',
            'ssn',
            'emp_status'
        ],
        "timestamp": [
            'hire_date',
            'term_date'
        ],
        "date_range": []
    }
}
